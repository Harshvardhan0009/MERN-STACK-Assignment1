export const users = [
    { id: 1, name: 'John Doe', email: 'john.doe@example.com', role: 'Developer' },
    { id: 2, name: 'Jane Smith', email: 'jane.smith@example.com', role: 'Designer' },
    { id: 3, name: 'Mike Johnson', email: 'mike.johnson@example.com', role: 'Manager' },
    { id: 4, name: 'Sarah Williams', email: 'sarah.williams@example.com', role: 'Developer' },
    { id: 5, name: 'Tom Brown', email: 'tom.brown@example.com', role: 'Analyst' },
    { id: 6, name: 'Emily Davis', email: 'emily.davis@example.com', role: 'Designer' },
    { id: 7, name: 'David Wilson', email: 'david.wilson@example.com', role: 'Developer' },
    { id: 8, name: 'Lisa Anderson', email: 'lisa.anderson@example.com', role: 'Manager' },
    { id: 9, name: 'James Taylor', email: 'james.taylor@example.com', role: 'Analyst' },
    { id: 10, name: 'Maria Garcia', email: 'maria.garcia@example.com', role: 'Developer' },
];
