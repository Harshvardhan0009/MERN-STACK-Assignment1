var a = 89;
let b = 92;

console.log(a);
console.log(b);

function test() {
  var c = 86;
  console.log(c);
}
test();
